#' @author Ivan Jacob Agaloos Pesigan
#'
#' @title rhoMatrix: Correlation Matrix
#'
#' @description A collection of functions related
#'   to the correlation matrix \eqn{\mathbf{P}}.
#'
#' @docType package
#' @name rhoMatrix
#' @keywords rhoMatrix package
NULL
