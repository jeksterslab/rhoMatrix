#' @rdname .check_rhocap
#' @noRd
.check_cor <- function(x,
                       return_k = FALSE) {
  .check_rhocap(
    x = x,
    return_k = return_k
  )
}
