#' @rdname .check_vechsrhocap
#' @noRd
.check_vechscor <- function(x,
                            return_k = FALSE) {
  .check_vechsrhocap(
    x = x,
    return_k = return_k
  )
}
