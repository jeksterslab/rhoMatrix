#' @rdname sigmacap_of_rhocap
#' @export
cov_of_cor <- function(x,
                       sd) {
  sigmacap_of_rhocap(
    x = x,
    sd = sd
  )
}
