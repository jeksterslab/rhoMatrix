#' @rdname rhocap_of_sigmacap
#' @export
cor_of_cov <- function(x) {
  rhocap_of_sigmacap(x)
}
