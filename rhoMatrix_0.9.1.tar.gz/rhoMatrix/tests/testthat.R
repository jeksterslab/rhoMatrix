library(testthat)
library(rhoMatrix)

test_check("rhoMatrix")
